/*
 * Copyright(C) 2015-2018 Renesas Electronics Corporation. All Rights Reserved.
 * RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY
 * This program must be used solely for the purpose for which
 * it was furnished by Renesas Electronics Corporation.
 * No part of this program may be reproduced or disclosed to
 * others, in any form, without the prior written permission
 * of Renesas Electronics Corporation.
 */
/**
 * OMXR Extension header for H.265 
 * 
 * This file contains vendor-defined extension definitions.
 *
 * \file OMXR_Extension_h265.h
 * 
 */

#ifndef OMXR_EXTENSION_H265_H
#define OMXR_EXTENSION_H265_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/***************************************************************************/
/*    Include Files                                                        */
/***************************************************************************/
#include "OMXR_Extension_video.h"

/***************************************************************************/
/*    Macro Definitions                                                    */
/***************************************************************************/
#define OMXR_MC_VendorBaseOffsetH265     (0x000001000)		/**< base offset for H.265 (internal use) */

#define OMXR_MC_IndexVendorBaseH265      (OMXR_MC_IndexVendorBaseVideo + OMXR_MC_VendorBaseOffsetH265)  /**< base value of extended OMX_INDEXTYPE for H.265  */
#define OMXR_MC_EventVendorBaseH265      (OMXR_MC_EventVendorBaseVideo + OMXR_MC_VendorBaseOffsetH265)  /**< base value of extended OMX_EVENTTYPE for H.265  */
#define OMXR_MC_ErrorVendorBaseH265      (OMXR_MC_ErrorVendorBaseVideo + OMXR_MC_VendorBaseOffsetH265)  /**< base value of extended OMX_ERRORTYPE for H.265  */

#define OMXR_MC_IndexParamVideoHevc             (OMXR_MC_IndexVendorBaseH265 + 0x0000)
#define OMXR_MC_IndexConfigVideoHEVCIntraPeriod (OMXR_MC_IndexVendorBaseH265 + 0x0001)


/** 
 * Enumeration of extended #OMX_VIDEO_CODINGTYPE
 */
enum {
	OMXR_MC_VIDEO_CodingHEVC = OMX_VIDEO_CodingVendorStartUnused + 0x0005	/**< H.265/HEV */
};


/***************************************************************************/
/*    Type  Definitions                                                    */
/***************************************************************************/
/** 
 * HEV profile types, each profile indicates support for various 
 * performance bounds and different annexes.
 */
typedef enum OMXR_MC_VIDEO_HEVCPROFILETYPE {
	OMXR_MC_VIDEO_HEVCProfileUnknown      = 0x00,
    OMXR_MC_VIDEO_HEVCProfileMain         = 0x01,    /**< Main profile */
    OMXR_MC_VIDEO_HEVCProfileMain10       = 0x02,    /**< Main 10 profile */
    OMXR_MC_VIDEO_HEVCProfileMainStillPic = 0x04,    /**< Main Still Picture profile */
    OMXR_MC_VIDEO_HEVProfileNone,                    /**< no profile */
    OMXR_MC_VIDEO_HEVProfileCustomizeStartUnused     /**< reserved to customize */
} OMXR_MC_VIDEO_HEVCPROFILETYPE;


/** 
 * HEV level types, each level indicates support for various frame sizes, 
 * bit rates, decoder frame rates.  No need 
 */
typedef enum OMXR_MC_VIDEO_HEVCLEVELTYPE {
    OMXR_MC_VIDEO_HEVCLevelUnknown    = 0x0,
    OMXR_MC_VIDEO_HEVCMainTierLevel1  = 0x1,              /**< Level 1 */
    OMXR_MC_VIDEO_HEVCHighTierLevel1  = 0x2,
    OMXR_MC_VIDEO_HEVCMainTierLevel2  = 0x4,              /**< Level 2 */
    OMXR_MC_VIDEO_HEVCHighTierLevel2  = 0x8,
    OMXR_MC_VIDEO_HEVCMainTierLevel21 = 0x10,             /**< Level 2.1 */
    OMXR_MC_VIDEO_HEVCHighTierLevel21 = 0x20,
    OMXR_MC_VIDEO_HEVCMainTierLevel3  = 0x40,             /**< Level 3 */
    OMXR_MC_VIDEO_HEVCHighTierLevel3  = 0x80,
    OMXR_MC_VIDEO_HEVCMainTierLevel31 = 0x100,            /**< Level 3.1 */
    OMXR_MC_VIDEO_HEVCHighTierLevel31 = 0x200,
    OMXR_MC_VIDEO_HEVCMainTierLevel4  = 0x400,            /**< Level 4 */
    OMXR_MC_VIDEO_HEVCHighTierLevel4  = 0x800,
    OMXR_MC_VIDEO_HEVCMainTierLevel41 = 0x1000,           /**< Level 4.1 */
    OMXR_MC_VIDEO_HEVCHighTierLevel41 = 0x2000,
    OMXR_MC_VIDEO_HEVCMainTierLevel5  = 0x4000,           /**< Level 5 */
    OMXR_MC_VIDEO_HEVCHighTierLevel5  = 0x8000,
    OMXR_MC_VIDEO_HEVCMainTierLevel51 = 0x10000,
    OMXR_MC_VIDEO_HEVCHighTierLevel51 = 0x20000,
    OMXR_MC_VIDEO_HEVCMainTierLevel52 = 0x40000,
    OMXR_MC_VIDEO_HEVCHighTierLevel52 = 0x80000,
    OMXR_MC_VIDEO_HEVCMainTierLevel6  = 0x100000,
    OMXR_MC_VIDEO_HEVCHighTierLevel6  = 0x200000,
    OMXR_MC_VIDEO_HEVCMainTierLevel61 = 0x400000,
    OMXR_MC_VIDEO_HEVCHighTierLevel61 = 0x800000,
    OMXR_MC_VIDEO_HEVCMainTierLevel62 = 0x1000000,
    OMXR_MC_VIDEO_HEVCHighTierLevel62 = 0x2000000,
    OMXR_MC_VIDEO_HEVLevelNone        = 0x7F000001,       /**< no level */
    OMXR_MC_VIDEO_HEVLevelCustomizeStartUnused            /**< reserved to customize */
} OMXR_MC_VIDEO_HEVCLEVELTYPE;


/** 
 * HEV loop filter modes 
 *
 * OMXR_MC_VIDEO_HEVLoopFilterEnable               : Enable
 * OMXR_MC_VIDEO_HEVLoopFilterDisable              : Disable
 * OMXR_MC_VIDEO_HEVLoopFilterDisableSliceBoundary : Disabled on slice boundaries
 */
typedef enum OMXR_MC_VIDEO_HEVLOOPFILTERTYPE {
    OMXR_MC_VIDEO_HEVLoopFilterEnable = 0,
    OMXR_MC_VIDEO_HEVLoopFilterDisable,
    OMXR_MC_VIDEO_HEVLoopFilterDisableSliceBoundary,
	OMXR_MC_VIDEO_HEVLoopFilterCustomizeStartUnused
} OMXR_MC_VIDEO_HEVLOOPFILTERTYPE;


/** 
 * HEV params 
 *
 * STRUCT MEMBERS:
 *  nSize                     : Size of the structure in bytes
 *  nVersion                  : OMX specification version information
 *  nPortIndex                : Port that this structure applies to
 *  nSliceHeaderSpacing       : Number of macroblocks between slice header, put  
 *                              zero if not used
 *  nPFrames                  : Number of P frames between each I frame
 *  nBFrames                  : Number of B frames between each I frame
 *  bUseHadamard              : Enable/disable Hadamard transform
 *  nRefFrames                : Max number of reference frames to use for inter
 *                              motion search (1-16)
 *  nRefIdxTrailing           : Pic param set ref frame index (index into ref
 *                              frame buffer of trailing frames list), B frame
 *                              support
 *  nRefIdxForward            : Pic param set ref frame index (index into ref
 *                              frame buffer of forward frames list), B frame
 *                              support
 *  bEnableUEP                : Enable/disable unequal error protection. This 
 *                              is only valid of data partitioning is enabled.
 *  bEnableFMO                : Enable/disable flexible macroblock ordering
 *  bEnableASO                : Enable/disable arbitrary slice ordering
 *  bEnableRS                 : Enable/disable sending of redundant slices
 *  eProfile                  : HEV profile(s) to use
 *  eLevel                    : HEV level(s) to use
 *  nAllowedPictureTypes      : Specifies the picture types allowed in the 
 *                              bitstream
 *  bFrameMBsOnly             : specifies that every coded picture of the 
 *                              coded video sequence is a coded frame 
 *                              containing only frame macroblocks
 *  bMBAFF                    : Enable/disable switching between frame and 
 *                              field macroblocks within a picture
 *  bEntropyCodingCABAC       : Entropy decoding method to be applied for the 
 *                              syntax elements for which two descriptors appear 
 *                              in the syntax tables
 *  bWeightedPPrediction      : Enable/disable weighted prediction shall not 
 *                              be applied to P and SP slices
 *  nWeightedBipredicitonMode : Default weighted prediction is applied to B 
 *                              slices 
 *  bconstIpred               : Enable/disable intra prediction
 *  bDirect8x8Inference       : Specifies the method used in the derivation 
 *                              process for luma motion vectors for B_Skip, 
 *                              B_Direct_16x16 and B_Direct_8x8 as specified 
 *                              in subclause 8.4.1.2 of the HEV spec 
 *  bDirectSpatialTemporal    : Flag indicating spatial or temporal direct
 *                              mode used in B slice coding (related to 
 *                              bDirect8x8Inference) . Spatial direct mode is 
 *                              more common and should be the default.
 *  nCabacInitIdx             : Index used to init CABAC contexts
 *  eLoopFilterMode           : Enable/disable loop filter
 */
typedef struct OMXR_MC_VIDEO_PARAM_HEVCTYPE {
    OMX_U32 nSize;                 
    OMX_VERSIONTYPE nVersion;      
    OMX_U32 nPortIndex;            
    OMX_U32 nSliceHeaderSpacing;  
    OMX_U32 nPFrames;     
    OMX_U32 nBFrames;     
    OMX_BOOL bUseHadamard;
    OMX_U32 nRefFrames;  
	OMX_U32 nRefIdx10ActiveMinus1;
	OMX_U32 nRefIdx11ActiveMinus1;
    OMX_BOOL bEnableUEP;  
    OMX_BOOL bEnableFMO;  
    OMX_BOOL bEnableASO;  
    OMX_BOOL bEnableRS;   
    OMXR_MC_VIDEO_HEVCPROFILETYPE eProfile;
	OMXR_MC_VIDEO_HEVCLEVELTYPE eLevel; 
    OMX_U32 nAllowedPictureTypes;  
	OMX_BOOL bFrameMBsOnly;        									
    OMX_BOOL bMBAFF;               
    OMX_BOOL bEntropyCodingCABAC;  
    OMX_BOOL bWeightedPPrediction; 
    OMX_U32 nWeightedBipredicitonMode; 
    OMX_BOOL bconstIpred ;
    OMX_BOOL bDirect8x8Inference;  
	OMX_BOOL bDirectSpatialTemporal;
	OMX_U32 nCabacInitIdc;
	OMXR_MC_VIDEO_HEVLOOPFILTERTYPE eLoopFilterMode;
	OMX_U32 nKeyFrameInterval;
} OMXR_MC_VIDEO_PARAM_HEVCTYPE;

/** 
 * HEV IDR Period Configs
 *
 * STRUCT MEMBERS:
 *  nSize      : Size of the structure in bytes
 *  nVersion   : OMX specification version information
 *  nPortIndex : Port that this structure applies to
 *  nIDRPeriod : Specifies periodicity of IDR frames
 *  nPFrames : Specifies internal of coding Intra frames
 */
typedef struct OMXR_MC_VIDEO_CONFIG_HEVCINTRAPERIOD {
    OMX_U32 nSize; 
    OMX_VERSIONTYPE nVersion;
    OMX_U32 nPortIndex;
    OMX_U32 nIDRPeriod;
    OMX_U32 nPFrames;
} OMXR_MC_VIDEO_CONFIG_HEVCINTRAPERIOD;


/***************************************************************************/
/*    Function Prototypes                                                  */
/***************************************************************************/

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* OMXR_EXTENSION_H265_H */
